    package="com.example.student_grades">
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity() {
}