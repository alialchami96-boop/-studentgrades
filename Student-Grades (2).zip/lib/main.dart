import 'package:flutter/material.dart';

void main() {
  runApp(const SimpleHomeApp());
}

class SimpleHomeApp extends StatelessWidget {
  const SimpleHomeApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Simple Home',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('الصفحة الرئيسية'),
          backgroundColor: Colors.blue,
        ),
        body: const Center(
          child: Text(
            'هذه هي الصفحة الرئيسية البسيطة',
            style: TextStyle(fontSize: 24),
          ),
        ),
      ),
    );
  }
}