import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/results_provider.dart';
import '../models/student.dart';
import '../screens/add_student_screen.dart';

class StudentTable extends StatelessWidget {
  const StudentTable({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ResultsProvider>(context);
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columns: const [
            DataColumn(label: Text('الاسم')),
            DataColumn(label: Text('المواد')),
            DataColumn(label: Text('المجموع'), numeric: true),
            DataColumn(label: Text('المعدل'), numeric: true),
            DataColumn(label: Text('الحالة')),
            DataColumn(label: Text('الإجراءات')),
          ],
          rows: provider.students.map((student) {
            final status = student.passes(provider.passingGrade) ? 'ناجح' : 'راسب';
            final statusColor = status == 'ناجح' ? Colors.green : Colors.red;

            return DataRow(cells: [
              DataCell(Text(student.name)),
              DataCell(Text(student.marks.keys.join(', '))),
              DataCell(Text(student.total.toStringAsFixed(1))),
              DataCell(Text(student.average.toStringAsFixed(1))),
              DataCell(Text(status, style: TextStyle(color: statusColor))),
              DataCell(Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit, color: Colors.blue),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AddStudentScreen(editId: student.id),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => provider.removeStudent(student.id),
                  ),
                ],
              )),
            ]);
          }).toList(),
        ),
      ),
    );
  }
}