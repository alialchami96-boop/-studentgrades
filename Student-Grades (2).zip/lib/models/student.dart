import 'dart:convert';

class Student {
  String id;
  String name;
  Map<String, double> marks; // subject -> mark

  Student({required this.id, required this.name, Map<String, double>? marks})
      : marks = marks ?? {};

  double get total => marks.values.fold(0.0, (a, b) => a + b);
  double get average => marks.isEmpty ? 0.0 : total / marks.length;

  bool passes(double passMark) => average >= passMark;

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'marks': marks.map((k, v) => MapEntry(k, v)),
      };

  factory Student.fromMap(Map<String, dynamic> m) {
    final rawMarks = Map<String, dynamic>.from(m['marks'] ?? {});
    final marks = rawMarks.map((k, v) => MapEntry(k, (v as num).toDouble()));
    return Student(id: m['id'], name: m['name'], marks: marks);
  }

  String toJson() => jsonEncode(toMap());
  factory Student.fromJson(String s) => Student.fromMap(jsonDecode(s));
}