import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/student.dart';

class ResultsProvider extends ChangeNotifier {
  List<Student> students = [];
  bool isDark = false;
  double passingGrade = 50.0;
  bool isLoading = true;
  final String storageKey = 'studentsv1';
  final String settingsKey = 'settingsv1';

  ResultsProvider();

  Future<void> loadAll() async {
    isLoading = true;
    notifyListeners();
    
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(storageKey) ?? [];
    students = raw.map((s) => Student.fromJson(s)).toList();
    
    final settingsRaw = prefs.getString(settingsKey);
    if (settingsRaw != null) {
      final map = jsonDecode(settingsRaw);
      isDark = map['isDark'] ?? isDark;
      passingGrade = (map['passingGrade'] ?? passingGrade).toDouble();
    }
    
    isLoading = false;
    notifyListeners();
  }

  Future<void> saveAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = students.map((s) => s.toJson()).toList();
    await prefs.setStringList(storageKey, raw);
    final settingsMap = {'isDark': isDark, 'passingGrade': passingGrade};
    await prefs.setString(settingsKey, jsonEncode(settingsMap));
  }

  void toggleTheme() {
    isDark = !isDark;
    saveAll();
    notifyListeners();
  }

  void setPassingGrade(double v) {
    passingGrade = v;
    saveAll();
    notifyListeners();
  }

  void addStudent(String name, Map<String, double> marks) {
    final id = const Uuid().v4();
    students.add(Student(id: id, name: name, marks: marks));
    saveAll();
    notifyListeners();
  }

  void updateStudent(String id, String name, Map<String, double> marks) {
    final idx = students.indexWhere((s) => s.id == id);
    if (idx >= 0) {
      students[idx].name = name;
      students[idx].marks = marks;
      saveAll();
      notifyListeners();
    }
  }

  void removeStudent(String id) {
    students.removeWhere((s) => s.id == id);
    saveAll();
    notifyListeners();
  }

  void importFromExcelData(List<Map<String, dynamic>> rows) {
    students.clear();
    for (var r in rows) {
      final name = r['name']?.toString() ?? 'Unknown';
      final marks = Map<String, double>.fromEntries(r.entries
          .where((e) => e.key != 'name')
          .map((e) => MapEntry(e.key, (e.value as num).toDouble())));
      students.add(Student(id: const Uuid().v4(), name: name, marks: marks));
    }
    saveAll();
    notifyListeners();
  }
}