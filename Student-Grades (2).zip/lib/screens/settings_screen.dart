import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/results_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  static const routeName = '/settings';

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ResultsProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('الوضع الليلي'),
              value: provider.isDark,
              onChanged: (v) => provider.toggleTheme(),
            ),
            const Divider(),
            ListTile(
              title: const Text('درجة النجاح'),
              subtitle: Slider(
                value: provider.passingGrade,
                min: 0,
                max: 100,
                divisions: 20,
                label: provider.passingGrade.toStringAsFixed(1),
                onChanged: (v) => provider.setPassingGrade(v),
              ),
            ),
          ],
        ),
      ),
    );
  }
}