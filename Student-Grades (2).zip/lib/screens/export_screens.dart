// lib/screens/export_screens.dart
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:excel/excel.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/student.dart';

class ExportPdfScreen extends StatelessWidget {
  final List<Student> students;
  final double passing;
  const ExportPdfScreen(
      {required this.students, required this.passing, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تصدير PDF')),
      body: Center(
        child: ElevatedButton(
          child: const Text('عرض وحفظ PDF'),
          onPressed: () async {
            final doc = pw.Document();
            doc.addPage(
              pw.MultiPage(
                build: (ctx) => [
                  pw.Header(
                    level: 0,
                    child: pw.Text('محصلات الطلاب',
                        style: const pw.TextStyle(fontSize: 24)),
                  ),
                  pw.Table.fromTextArray(
                    context: ctx,
                    data: <List<String>>[
                      ['الاسم', 'المواد', 'المجموع', 'المعدل', 'الحالة'],
                      ...students.map((s) => [
                            s.name,
                            s.marks.keys.join(', '),
                            s.total.toStringAsFixed(1),
                            s.average.toStringAsFixed(1),
                            s.passes(passing) ? 'ناجح' : 'راسب'
                          ])
                    ],
                  ),
                ],
              ),
            );
            final bytes = await doc.save();
            await Printing.sharePdf(bytes: bytes, filename: 'results.pdf');
          },
        ),
      ),
    );
  }
}

class ExportExcelScreen extends StatelessWidget {
  final List<Student> students;
  const ExportExcelScreen({required this.students, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تصدير Excel')),
      body: Center(
        child: ElevatedButton(
          child: const Text('حفظ ومشاركة Excel'),
          onPressed: () async {
            var excel = Excel.createExcel();
            Sheet sheetObject = excel['Results'];
            final header = ['الاسم', 'المواد', 'المجموع', 'المعدل', 'الحالة'];
            sheetObject.appendRow(header);
            for (var s in students) {
              sheetObject.appendRow([
                s.name,
                s.marks.entries.map((e) => '${e.key}:${e.value}').join('; '),
                s.total,
                s.average,
                s.average >= 0 ? (s.average >= 50 ? 'ناجح' : 'راسب') : ''
              ]);
            }
            final fileBytes = excel.encode();
            if (fileBytes == null) return;

            final dir = await getTemporaryDirectory();
            final file = File('${dir.path}/results.xlsx');
            await file.writeAsBytes(fileBytes);
            await Printing.sharePdf(
                bytes: await file.readAsBytes(), filename: 'results.xlsx');
          },
        ),
      ),
    );
  }
}