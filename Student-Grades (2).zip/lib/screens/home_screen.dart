import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/results_provider.dart';
import '../widgets/student_table.dart';
import 'add_student_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ResultsProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('نتائج الطلاب'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddStudentScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, SettingsScreen.routeName),
          ),
        ],
      ),
      body: const StudentTable(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // TODO: Add export functionality
        },
        child: const Icon(Icons.share),
      ),
    );
  }
}