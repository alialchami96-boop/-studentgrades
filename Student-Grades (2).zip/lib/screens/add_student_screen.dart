import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/results_provider.dart';
import '../models/student.dart';

class AddStudentScreen extends StatefulWidget {
  final String? editId;
  const AddStudentScreen({this.editId, Key? key}) : super(key: key);

  @override
  State<AddStudentScreen> createState() => _AddStudentScreenState();
}

class _AddStudentScreenState extends State<AddStudentScreen> {
  final _form = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final Map<String, TextEditingController> _marks = {};
  final Map<String, TextEditingController> _scores = {};

  @override
  void initState() {
    super.initState();
    if (widget.editId != null) {
      final prov = Provider.of<ResultsProvider>(context, listen: false);
      final student = prov.students.firstWhere(
        (s) => s.id == widget.editId,
        orElse: () => Student(id: '', name: ''),
      );
      if (student.id.isNotEmpty) {
        _nameCtrl.text = student.name;
        for (var entry in student.marks.entries) {
          _marks[entry.key] = TextEditingController(text: entry.key);
          _scores[entry.key] = TextEditingController(text: entry.value.toString());
        }
      }
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    for (var c in _marks.values) c.dispose();
    for (var c in _scores.values) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(widget.editId == null ? 'إضافة طالب' : 'تعديل طالب')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Form(
          key: _form,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'اسم الطالب'),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'ادخل الاسم' : null,
              ),
              const SizedBox(height: 20),
              ..._subjectFields(),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    child: const Text('إضافة مادة'),
                    onPressed: () {
                      setState(() {
                        final key = UniqueKey().toString();
                        _marks[key] = TextEditingController();
                        _scores[key] = TextEditingController();
                      });
                    },
                  ),
                  ElevatedButton(
                    child: const Text('حفظ'),
                    onPressed: () => _save(context),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _subjectFields() {
    return _marks.keys.map((key) {
      return Row(
        children: [
          Expanded(
            flex: 5,
            child: TextFormField(
              controller: _marks[key],
              decoration: const InputDecoration(labelText: 'اسم المادة'),
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'ادخل اسم المادة' : null,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 3,
            child: TextFormField(
              controller: _scores[key],
              decoration: const InputDecoration(labelText: 'الدرجة'),
              keyboardType: TextInputType.number,
              validator: (v) {
                if (v == null || v.trim().isEmpty) return 'ادخل الدرجة';
                final score = double.tryParse(v);
                if (score == null || score < 0 || score > 100) {
                  return 'درجة غير صالحة';
                }
                return null;
              },
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () => setState(() {
              _marks.remove(key);
              _scores.remove(key);
            }),
          ),
        ],
      );
    }).toList();
  }

  void _save(BuildContext context) {
    if (_form.currentState!.validate()) {
      final prov = Provider.of<ResultsProvider>(context, listen: false);
      final marks = <String, double>{};

      for (var key in _marks.keys) {
        final subject = _marks[key]!.text.trim();
        final score = double.tryParse(_scores[key]!.text) ?? 0.0;
        marks[subject] = score;
      }

      if (widget.editId != null) {
        prov.updateStudent(widget.editId!, _nameCtrl.text, marks);
      } else {
        prov.addStudent(_nameCtrl.text, marks);
      }
      Navigator.pop(context);
    }
  }
}